/*
 * timers.c
 *
 *  Created on: 16 maj 2024
 *      Author: gbednarski
 */

#include "timers.h"
#include "rf_driver_hal_vtimer.h"
#include "rf_driver_ll_utils.h"
#include "rf_driver_hal_power_manager.h"

#include "stdio.h"
#include "stdint.h"
#include "stdlib.h"
#include "custom_utils.h"
#include "main.h"

#define SENSORS_NUMBER 16

uint8_t k = 0;
extern volatile uint8_t rx_stop;
extern volatile uint8_t loop_end;
extern uint8_t sensor_nr;
extern struct MESS_s message_send; // struktura danych sensora
extern volatile struct MESS_SYNC_s mess_sync; // pakiet sync
extern uint8_t adv_type; //0=legacy, 1=extended, 2 = periodic
extern volatile uint16_t sensors_presence[SENSORS_NUMBER][2];
extern volatile uint8_t to_start_loop;

#define HS_STARTUP_TIME			780

uint32_t slot_time = 60;
uint8_t sync_channel = 20;
volatile uint32_t del_loop_offset = 0;
uint8_t current_sync_slot = 0;

void callback_rx_slot(void *handle);
void callback_tx_slot(void *handle);
void callback_tx_synchro(void *handle);
void callback_rx_synchro(void *handle);
void callback_tx_alarm(void *handle);
void callback_rx_alarm(void *handle);
void callback_acc(void *handle);
void callback_th(void *handle);
void callback_print(void *handle);
void callback_loop(void *handle);
void callback_to_start_loop(void *handle);
void callback_adv(void *handle);


VTIMER_HandleType timerHandle_tab[SENSORS_NUMBER];
VTIMER_HandleType timerHandle_tx_slot;
VTIMER_HandleType timerHandle_tx_synchro_tab[DELAY_LOOP/1000];
VTIMER_HandleType timerHandle_rx_synchro;
VTIMER_HandleType timerHandle_tx_alarm;
VTIMER_HandleType timerHandle_rx_alarm;
VTIMER_HandleType timerHandle_acc;
VTIMER_HandleType timerHandle_th;
VTIMER_HandleType timerHandle_print;
VTIMER_HandleType timerHandle_loop;
VTIMER_HandleType timerHandle_to_start_loop;
VTIMER_HandleType timerHandle_adv;

//VTIMER_HandleType * timerHandle_tab;

void callback_tx_slot(void *handle)
{
	//  TX_packets(sensor_nr, (uint8_t *)&message_send, sizeof(message_send), RX_ACK); // sensor nr is equal to channel number
}

void callback_rx_slot(void *handle)
{
	//Identifying slot number  = sensor number = channel number
	uint8_t ch = 0; //channel
	for(uint8_t k = 0; k < SENSORS_NUMBER; k++)
	{
		if((VTIMER_HandleType *)handle == (VTIMER_HandleType *)&(timerHandle_tab[k]))
		{
			ch = k;
			break;
		}
	}

	sensors_presence[ch][0] = 0;

	uint8_t raw_ble_rx_message[1];
	uint16_t raw_ble_rx_message_size = 0;

	//RX_packets(ch, &raw_ble_rx_message[0], &raw_ble_rx_message_size, RX_SLOT_TIMEOUT, TX_ACK);
}

void callback_tx_synchro(void *handle)
{
	//set_synchro_message(current_sync_slot);
	//TX_packets(sync_channel, (uint8_t *)&mess_sync, sizeof(mess_sync), RX_NO_ACK);
	current_sync_slot++;
}

void callback_rx_synchro(void *handle)
{
	uint8_t raw_ble_rx_message[1];
	uint16_t raw_ble_rx_message_size = 0;
}

void callback_loop(void *handle)
{
	loop_end = 1;
}

void callback_to_start_loop(void *handle)
{
	to_start_loop = 1;
}

void callback_acc(void *handle)
{
#if SENSOR == 1
	  	//INT1_ACC_Callback();
#endif
}

void callback_th(void *handle)
{
		//sensor_data_collection();
}

void callback_print(void *handle)
{
	//print_sensors(0, SENSORS_NUMBER);
	LL_mDelay(5);
}

void callback_adv(void *handle)
{
	  WakeupSourceConfig_TypeDef wakeupIO = {0,0,0,0};
	  PowerSaveLevels stopLevel;
	  static volatile uint8_t adv = 0;
	  for(adv = 0; adv < SENSORS_NUMBER; adv++)
	{
		adv_type = 0;
		ModulesTick();
		//Stop_Beaconing();
		ModulesTick();
		//beaconing(ADV_DEBUG, adv);
		HAL_PWR_MNGR_Request(POWER_SAVE_LEVEL_STOP_WITH_TIMER, wakeupIO, &stopLevel);
	}
  	  ModulesTick();
	  //Stop_Beaconing();
}



/***********************************************************************************************************/

#if SENSOR == 1

void timer_management_sensor(void)
{
	// creation vtimer handlers
//	timerHandle_rx_synchro.callback = callback_rx_synchro;
	timerHandle_tx_slot.callback = callback_tx_slot;
//	timerHandle_acc.callback = callback_acc;
	timerHandle_th.callback = callback_th;
	timerHandle_loop.callback = callback_loop;
}

void timer_loop_sensor(void)
{
	// start of (SENSORS_NUMBER) * vtimer handlers - in order to let all of them count from the same point in time

	HAL_VTIMER_StartTimerMs(&timerHandle_rx_synchro, DELAY_RX_SYNCHRO);

		static uint8_t soo = 0;
		if(soo >= 0)
			{
			HAL_VTIMER_StartTimerMs(&timerHandle_tx_slot, (sensor_nr * SLOT_TIME) + TIME_SLOT_DELTA + 20);
				soo = 0;
			}
		soo++;


		//HAL_VTIMER_StartTimerMs(&timerHandle_acc, DELAY_ACC);

		static uint32_t th_measurement_period = 0;
		if(th_measurement_period >= TH_MEASUREMENT_PERIOD)
			{
				HAL_VTIMER_StartTimerMs(&timerHandle_th, DELAY_TH);
				th_measurement_period = 0;
			}
		th_measurement_period = th_measurement_period + DELAY_LOOP;

		HAL_VTIMER_StartTimerMs(&timerHandle_loop, DELAY_LOOP - del_loop_offset);
}

/*
 * Function called to wait for right moment to start loop
 */
void synchro_to_start_loop(void)
{
	timerHandle_to_start_loop.callback = callback_to_start_loop;
	LL_mDelay(1);

	//if(mess_sync.sync_slot == 0)
	{
	//	mess_sync.sync_slot = mess_sync.total_sync_slots;
	}

	//HAL_VTIMER_StartTimerMs(&timerHandle_to_start_loop, ((mess_sync.total_sync_slots - mess_sync.sync_slot) * 1000));
}

#elif ROUTER == 1
void timer_management_router(void)
{
// creation of vtimer handlers for each of sync_slots
	for(uint8_t k = 0; k < (DELAY_LOOP/1000); k++)
	{
		(*(timerHandle_tx_synchro_tab+k)).callback = callback_tx_synchro;
	}

// creation of vtimer handlers for each of (SENSORS_NUMBER)
	for(uint8_t k = 0; k < SENSORS_NUMBER; k++)
	{
		(*(timerHandle_tab+k)).callback = callback_rx_slot;
	}

	timerHandle_loop.callback = callback_loop;
	timerHandle_print.callback = callback_print;
	timerHandle_adv.callback = callback_adv;
}

void timer_loop_router(void)
{
	// start of (DELAY_LOOP/1000) * SYNC_SLOT_TIME vtimer handlers - in order to send sync message every second
		current_sync_slot = 0;
		for(uint8_t k = 0; k < (DELAY_LOOP/1000); k++)
		{
			HAL_VTIMER_StartTimerMs(&timerHandle_tx_synchro_tab[k], ((k * SYNC_SLOT_TIME) + DELAY_TX_SYNCHRO));
		}

	// start of (SENSORS_NUMBER) * vtimer handlers - in order to let all of them count from the same point in time
		for(uint8_t k = 0; k < SENSORS_NUMBER; k++)
		{
			HAL_VTIMER_StartTimerMs(&timerHandle_tab[k], ((k * SLOT_TIME) + TIME_SLOT_DELTA));
		}

		//HAL_VTIMER_StartTimerMs(&timerHandle_print, DELAY_PRINT);
		HAL_VTIMER_StartTimerMs(&timerHandle_loop, DELAY_LOOP);
		HAL_VTIMER_StartTimerMs(&timerHandle_adv, DELAY_ADV);
}

#endif
