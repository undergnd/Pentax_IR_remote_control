/*
 * custom_utils.c
 *
 *  Created on: 5 maj 2024
 *      Author: gbednarski
 */

#include <stdio.h>
#include "custom_utils.h"
#include "rf_driver_ll_gpio.h"
#include "rf_driver_ll_bus.h"
#include "rf_driver_ll_utils.h"


void delay_custom(uint32_t delayCount_custom) {
	volatile uint32_t delayCount = delayCount_custom;

	while (delayCount > 0) {
		delayCount--;
	}
}

void stop_f(void)
{
	while(1)
	{
	}
}




