/*
 * timers.h
 *
 *  Created on: 16 maj 2024
 *      Author: gbednarski
 */

#ifndef INC_TIMERS_H_
#define INC_TIMERS_H_

#define SLOT_TIME 60 //period in ms
#define SYNC_SLOT_TIME 1000 //period in ms
#define TIME_SLOT_DELTA 50 //time slot block offset
#define DELAY_TX_SYNCHRO 0
#define DELAY_RX_SYNCHRO 0
#define DELAY_LOOP 5000
#define DELAY_LOOP_OFFSET 5
#define DELAY_ACC 1280
#define DELAY_PRINT 1130
#define DELAY_TH 1230
//#define DELAY_ADV 2000
#define DELAY_ADV 4200

#define TH_MEASUREMENT_PERIOD 60000 // in ms - you can set temp hum measurement time

//#define SKIP_SYNCHRO_COUNTER 20
#define SKIP_SYNCHRO_COUNTER 10

#define RX_ACK 1
#define RX_NO_ACK 0
#define TX_ACK 1
#define TX_NO_ACK 0
#define RX_SLOT_TIMEOUT ((slot_time * 1000) - (20 * 1000))
#define RX_SYNC_TIMEOUT (DELAY_LOOP * 200) // 1 second

void timer_management_sensor(void);
void timer_loop_sensor(void);
void timer_management_router(void);
void timer_loop_router(void);
void synchro_to_start_loop(void);

#endif /* INC_TIMERS_H_ */
