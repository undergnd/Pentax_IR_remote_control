/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BLUENRG_LP_EVB_COM_H
#define __BLUENRG_LP_EVB_COM_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "bluenrg_lpx.h"
#include "rf_driver_ll_bus.h"
#include "rf_driver_ll_exti.h"
#include "rf_driver_ll_gpio.h"
#include "rf_driver_ll_usart.h"
#include "rf_driver_ll_i2c.h"
#include "rf_driver_ll_spi.h"
#include "rf_driver_hal_power_manager.h"

#include <stdio.h>
   
/*
// TX - port A9, RX - port A8
#define BSP_UART                                   USART1
#define BSP_UART_IRQn                              USART1_IRQn
#define BSP_UART_BAUDRATE                          (115200)
#define BSP_UART_CLK_ENABLE()                      LL_APB1_EnableClock(LL_APB1_PERIPH_USART)
#define BSP_UART_CLK_DISABLE()                     LL_APB1_DisableClock(LL_APB1_PERIPH_USART)
#define BSP_UART_GPIO_CLOCK_ENABLE()               LL_AHB_EnableClock(LL_AHB_PERIPH_GPIOA)
#define BSP_UART_GPIO_CLOCK_DISABLE()              LL_AHB_DisableClock(LL_AHB_PERIPH_GPIOA)

#define BSP_UART_TX_PIN                           LL_GPIO_PIN_9
#define BSP_UART_TX_GPIO_PORT                     GPIOA
#define BSP_UART_TX_GPIO_AF_N                     LL_GPIO_AF_0
#define BSP_UART_TX_GPIO_AF()                     LL_GPIO_SetAFPin_8_15(GPIOA, LL_GPIO_PIN_9, LL_GPIO_AF_0)
#define BSP_UART_TX_GPIO_CLK_ENABLE()             LL_AHB_EnableClock(LL_AHB_PERIPH_GPIOA)
#define BSP_UART_TX_GPIO_CLK_DISABLE()            LL_AHB_DisableClock(LL_AHB_PERIPH_GPIOA)

#define BSP_UART_RX_PIN                           LL_GPIO_PIN_8
#define BSP_UART_RX_GPIO_PORT                     GPIOA
#define BSP_UART_RX_GPIO_AF_N                     LL_GPIO_AF_0
#define BSP_UART_RX_GPIO_AF()                     LL_GPIO_SetAFPin_8_15(GPIOA, LL_GPIO_PIN_8, LL_GPIO_AF_0)
#define BSP_UART_RX_GPIO_CLK_ENABLE()             LL_AHB_EnableClock(LL_AHB_PERIPH_GPIOA)
#define BSP_UART_RX_GPIO_CLK_DISABLE()            LL_AHB_DisableClock(LL_AHB_PERIPH_GPIOA)
*/


 // TX - port B9, RX - port B0
 #define BSP_UART                                  USART1
 #define BSP_UART_IRQn                             USART1_IRQn
 #define BSP_UART_BAUDRATE                         (115200)
 #define BSP_UART_CLK_ENABLE()                     LL_APB1_EnableClock(LL_APB1_PERIPH_USART)
 #define BSP_UART_CLK_DISABLE()                    LL_APB1_DisableClock(LL_APB1_PERIPH_USART)
 #define BSP_UART_GPIO_CLOCK_ENABLE()              LL_AHB_EnableClock(LL_AHB_PERIPH_GPIOB)
 #define BSP_UART_GPIO_CLOCK_DISABLE()             LL_AHB_DisableClock(LL_AHB_PERIPH_GPIOB)

 #define BSP_UART_TX_PIN                           LL_GPIO_PIN_9
 #define BSP_UART_TX_GPIO_PORT                     GPIOB
 #define BSP_UART_TX_GPIO_AF_N                     LL_GPIO_AF_0
 #define BSP_UART_TX_GPIO_AF()                     LL_GPIO_SetAFPin_8_15(GPIOB, LL_GPIO_PIN_9, LL_GPIO_AF_0)
 #define BSP_UART_TX_GPIO_CLK_ENABLE()             LL_AHB_EnableClock(LL_AHB_PERIPH_GPIOB)
 #define BSP_UART_TX_GPIO_CLK_DISABLE()            LL_AHB_DisableClock(LL_AHB_PERIPH_GPIOB)

 #define BSP_UART_RX_PIN                           LL_GPIO_PIN_0
 #define BSP_UART_RX_GPIO_PORT                     GPIOB
 #define BSP_UART_RX_GPIO_AF_N                     LL_GPIO_AF_0
 #define BSP_UART_RX_GPIO_AF()                     LL_GPIO_SetAFPin_0_7(GPIOB, LL_GPIO_PIN_0, LL_GPIO_AF_0)
 #define BSP_UART_RX_GPIO_CLK_ENABLE()             LL_AHB_EnableClock(LL_AHB_PERIPH_GPIOB)
 #define BSP_UART_RX_GPIO_CLK_DISABLE()            LL_AHB_DisableClock(LL_AHB_PERIPH_GPIOB)

/**
 * @brief  BSP_COM_RxDataCb_t User callback type 
 */
typedef void (* BSP_COM_RxDataCb_t) (uint8_t * pRxDataBuff, uint16_t nDataSize);

void COM_Init(BSP_COM_RxDataCb_t pRxDataCb);
void rekrutacja_COM_Init(BSP_COM_RxDataCb_t pRxDataCb, uint32_t speed);

void COM_DeInit(void);
void COM_Write(uint8_t *pBuff, uint8_t nBuffSize);
uint8_t COM_Read(uint8_t *pData);
void COM_IRQHandler(void);

void COM_RxDataUserCb(uint8_t * pRxDataBuff, uint16_t nDataSize);
uint8_t COM_TxFifoNotEmpty(void);
uint8_t COM_UARTBusy(void);

#ifdef __cplusplus
}
#endif

#endif /* __BLUENRG_LP_EVB_COM_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

