/*
 * custom_utils.h
 *
 *  Created on: 5 maj 2024
 *      Author: gbednarski
 */

#ifndef INC_CUSTOM_UTILS_H_
#define INC_CUSTOM_UTILS_H_

#include <stdio.h>

void delay_custom(uint32_t delayCount_custom);


void stop_f(void);


#endif /* INC_CUSTOM_UTILS_H_ */
