/*
 * spi_config.h
 *
 *  Created on: 7 kwi 2024
 *      Author: gbednarski
 */

#ifndef INC_SPI_CONFIG_H_
#define INC_SPI_CONFIG_H_

/* Includes ------------------------------------------------------------------*/
#include "rf_driver_ll_dma.h"
#include "rf_driver_ll_rcc.h"
#include "rf_driver_ll_bus.h"
#include "rf_driver_ll_system.h"
#include "rf_driver_ll_exti.h"
#include "rf_driver_ll_cortex.h"
#include "rf_driver_ll_utils.h"
#include "rf_driver_ll_spi.h"
#include "rf_driver_ll_gpio.h"

/* Private includes ----------------------------------------------------------*/

/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions prototypes ---------------------------------------------*/
void DMA_ReceiveComplete_Callback(void);
void DMA_TransmitComplete_Callback(void);
void SPI_MASTER_TransferError_Callback(void);
void UserButton_Callback(void);

void SPI_init(void);
void SPI_GPIOs_DeInit(void);
void Activate_SPI(void);
void WaitAndCheckEndOfTransfer(void);

    /**SPI_MASTER GPIO Configuration
    SPI2:
    PA5/AF1    ------> SPI2_SCK
    PA7/AF1    ------> SPI2_MISO
    PA6/AF1    ------> SPI2_MOSI
    */
#define GPIO_PORT_MASTER_SCK                    GPIOA
#define GPIO_PORT_MASTER_MISO                   GPIOA
#define GPIO_PORT_MASTER_MOSI                   GPIOA
#define GPIO_PIN_SPI_MASTER_SCK                 LL_GPIO_PIN_5
#define GPIO_PIN_SPI_MASTER_MISO                LL_GPIO_PIN_7
#define GPIO_PIN_SPI_MASTER_MOSI                LL_GPIO_PIN_6
#define GPIO_AF_SPI_MASTER_SCK                  LL_GPIO_AF_1
#define GPIO_AF_SPI_MASTER_MISO                 LL_GPIO_AF_1
#define GPIO_AF_SPI_MASTER_MOSI                 LL_GPIO_AF_1
#define SPI_MASTER                              SPI2
#define LL_SPI_Master_EnableClock()             LL_APB1_EnableClock(LL_APB1_PERIPH_SPI2)
#define SPI_MASTER_IRQn                         SPI2_IRQn
#define SPI_MASTER_IRQHandler                   SPI2_IRQHandler
#define LL_DMAMUX_REQ_SPI_MASTER_TX             LL_DMAMUX_REQ_SPI2_TX
#define LL_DMAMUX_REQ_SPI_MASTER_RX             LL_DMAMUX_REQ_SPI2_RX


#endif /* INC_SPI_CONFIG_H_ */
