/*
 * i2c_config.h
 *
 *  Created on: 13 kwi 2024
 *      Author: gbednarski
 */

#ifndef INC_I2C_CONFIG_H_
#define INC_I2C_CONFIG_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "rf_driver_ll_i2c.h"
#include "rf_driver_ll_rcc.h"
#include "rf_driver_ll_bus.h"
#include "rf_driver_ll_system.h"
#include "rf_driver_ll_exti.h"
#include "rf_driver_ll_cortex.h"
#include "rf_driver_ll_utils.h"
#include "rf_driver_ll_pwr.h"
#include "rf_driver_ll_dma.h"
#include "rf_driver_ll_gpio.h"
#include "bluenrg_lpx.h"

/* Private includes ----------------------------------------------------------*/

/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/

/**
  * @brief Slave settings
  */
/* #define SLAVE_OWN_ADDRESS                       180 */ /* This value is a left shift of a real 7 bits of a slave address
                                                        value which can find in a Datasheet as example: b0101101
                                                        mean in uint8_t equivalent at 0x2D and this value can be
                                                        seen in the OAR1 register in bits OA1[1:7] */

#define SLAVE_OWN_ADDRESS                       0x80

/** Uncomment this line to use the board as slave, if not it is used as master */
//#define SLAVE_BOARD

#define I2Cx                          I2C2
#define I2Cx_SCL_PORT                 GPIOA
#define I2Cx_SCL_PIN                  LL_GPIO_PIN_13
#define I2Cx_SCL_AF                   LL_GPIO_AF_0
#define I2Cx_SDA_PORT                 GPIOA
#define I2Cx_SDA_PIN                  LL_GPIO_PIN_14
#define I2Cx_SDA_AF                   LL_GPIO_AF_0
#define I2Cx_IRQn                     I2C2_IRQn
#define I2Cx_IRQHandler               I2C2_IRQHandler
#define LL_I2Cx_SCL_EnableClock()     LL_AHB_EnableClock(LL_AHB_PERIPH_GPIOA)
#define LL_I2Cx_SDA_EnableClock()     LL_AHB_EnableClock(LL_AHB_PERIPH_GPIOA)
#define LL_DMAMUX_REQ_I2Cx_RX         LL_DMAMUX_REQ_I2C2_RX
#define LL_DMAMUX_REQ_I2Cx_TX         LL_DMAMUX_REQ_I2C2_TX
#define LL_I2Cx_EnableClock()         LL_APB1_EnableClock(LL_APB1_PERIPH_I2C2)

/* Exported macro ------------------------------------------------------------*/

/* Exported functions prototypes ---------------------------------------------*/
void i2c_config_init(void);
void Handle_I2C_TX(void);
void Handle_I2C_RX(void);
void enable_DMA_Req_TX(void);
void enable_DMA_Req_RX(void);
void Error_Handler(void);


/* IRQ Handler treatment functions */
void UserButton_Callback(void);
void DMA1_Transfer_RX_Complete_Callback(void);
void DMA1_Transfer_TX_Complete_Callback(void);
void DMA1_Transfer_Error_Callback(void);
void Error_Callback(void);

/* Private defines -----------------------------------------------------------*/
/**
  * @brief BSP_LED2
  */

#define USER_BUTTON_PIN                         LL_GPIO_PIN_10
#define USER_BUTTON_GPIO_PORT                   GPIOA
#define USER_BUTTON_GPIO_CLK_ENABLE()           LL_AHB_EnableClock(LL_AHB_PERIPH_GPIOA)
#define USER_BUTTON_SYSCFG_CLK_ENABLE()         LL_APB0_EnableClock(LL_APB0_PERIPH_SYSCFG)
#define USER_BUTTON_EXTI_LINE                   LL_EXTI_LINE_PA10
#define USER_BUTTON_EXTI_IRQn                   GPIOA_IRQn
#define USER_BUTTON_EXTI_LINE_ENABLE()          LL_EXTI_EnableIT(USER_BUTTON_EXTI_LINE)
#define USER_BUTTON_EXTI_RISING_TRIG_ENABLE()   LL_EXTI_SetTrigger(LL_EXTI_TRIGGER_RISING_EDGE, USER_BUTTON_EXTI_LINE)


#ifdef __cplusplus
}
#endif


#endif /* INC_I2C_CONFIG_H_ */
